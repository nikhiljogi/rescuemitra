package com.example.rescuemitraapp.utils

const val MY_PREFS_NAME = "MyPrefsFile"
const val IS_USER_LOGIN_PREF_KEY = "IsUserLoginPrefKey"
const val USER_TYPE_PREF_KEY = "USerTypePrefKey"

const val USER_TYPE_INTENT_KEY = "USER_TYPE_INTENT_KEY"
const val USER_TYPE_RESCUE_AGENCY = "RESCUE_USER"
const val USER_TYPE_CITIZEN = "CITIZEN_USER"